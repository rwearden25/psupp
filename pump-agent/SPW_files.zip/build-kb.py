#!/usr/bin/env python3
"""
build-kb.py — General Pump Knowledge Base Builder
==================================================
Reads PDF manuals and generates knowledge-base.js for the troubleshooter app.

Usage:
    python3 build-kb.py [pdf_folder]

    pdf_folder: Path to folder containing PDF files (default: current directory)

Requirements:
    pip install pdfplumber
    For scanned/image PDFs: sudo apt install tesseract-ocr
                            pip install pytesseract Pillow

Output:
    knowledge-base.js — ready to use with index.html
"""

import os
import sys
import re
import json
import datetime

try:
    import pdfplumber
except ImportError:
    print("ERROR: pdfplumber not installed. Run: pip install pdfplumber")
    sys.exit(1)

# ─── CONFIG ───
PDF_FOLDER = sys.argv[1] if len(sys.argv) > 1 else "."
OUTPUT_FILE = "knowledge-base.js"


def extract_text(pdf_path):
    """Extract text from a PDF, falling back to OCR for image-based pages."""
    pages = []
    try:
        pdf = pdfplumber.open(pdf_path)
        for i, page in enumerate(pdf.pages):
            text = page.extract_text() or ""
            if not text.strip():
                # Try OCR fallback
                try:
                    import pytesseract
                    from PIL import Image
                    img = page.to_image(resolution=300).original
                    text = pytesseract.image_to_string(img)
                except Exception:
                    pass
            pages.append(text)
        pdf.close()
    except Exception as e:
        print(f"  WARNING: Could not read {pdf_path}: {e}")
    return pages


def extract_pump_models(pages):
    """Extract pump model specs from catalog pages."""
    models = []
    seen = set()
    for text in pages:
        for line in text.split("\n"):
            m = re.search(
                r"([A-Z][A-Z0-9]+\w+)\s+(\d+\.?\d*)\s*GPM\s+(\d[\d,]+)\s*PSI\s+(\d+)\s*RPM",
                line,
            )
            if m:
                model = m.group(1)
                if model in seen:
                    continue
                seen.add(model)
                gpm = m.group(2)
                psi = m.group(3).replace(",", "")
                rpm = m.group(4)
                hp_m = re.search(r"(\d+\.?\d*)\s*(GHP|EBHP|EHP|HP)", line)
                hp = f"{hp_m.group(1)} {hp_m.group(2)}" if hp_m else ""
                wt_m = re.search(r"(\d+\.?\d*)\s*lbs", line)
                wt = wt_m.group(1) if wt_m else ""

                # Determine series from model prefix
                series = classify_series(model)
                models.append([model, gpm, psi, rpm, hp, wt, series])
    return models


def classify_series(model):
    """Classify a pump model into its series."""
    prefix_map = {
        "ET": "E1/ET 53", "EP": "E2/EP 58", "ES": "E3/ES 59", "ESN": "E3/ES 59",
        "TT": "51", "TP": "51", "TC": "60", "TX": "63",
        "EZ": "EZ 44", "TSF": "66 TSF", "TSP": "66 TSP", "TSS": "47SS",
        "HTC": "Emperor HTC", "HTS": "Emperor HTS", "HTF": "Emperor HTF",
        "HTXS": "Emperor HTXS", "HTCK": "Emperor HTCK", "PEHT": "Emperor PEHT",
        "HTW": "Emperor HTW",
        "CW": "CW Vehicle", "KE": "KE", "KT": "KT", "KF": "KF", "KFZ": "KFZ",
        "KS": "KS", "HS": "HS", "HF": "HF", "HFN": "HFN",
        "MK": "MK", "MKS": "MKS", "MW": "MW", "MWS": "MW", "MWN": "MWN",
        "LK": "LK", "LKN": "LKN", "SK": "SK", "VFH": "VFH", "VKH": "VKH",
        "TR": "TR/SR", "SR": "TR/SR", "WM": "WM Aggressive", "EWM": "EWM Aggressive",
        "AT": "Agriculture", "AB": "Agriculture", "SM": "SM",
    }
    # Match longest prefix first
    for pfx in sorted(prefix_map.keys(), key=len, reverse=True):
        if model.startswith(pfx):
            return prefix_map[pfx]
    prefix = re.match(r"([A-Z]+)", model)
    if prefix and prefix.group(1) == "T" and len(model) < 8:
        return "47/50/69"
    if prefix and prefix.group(1) == "TS":
        return "47 TS"
    return "Other"


def extract_accessories(pages):
    """Extract accessory items from catalog pages."""
    accessories = {}
    current_section = None
    for text in pages:
        # Detect section headers
        headers = re.findall(
            r"(UNLOADERS?|RELIEF VALVES?|INJECTORS?|SPRAY (?:GUNS|TIPS)|NOZZLES?|"
            r"LANCES?|COUPLERS?|FILTERS?|GAUGES?|SWITCHES?|PULLEYS?|"
            r"SURFACE CLEANERS?|HOSE REELS?|OIL|CLUTCH)",
            text.upper(),
        )
        if headers:
            current_section = headers[0].title()

        for line in text.split("\n"):
            am = re.match(r"([A-Z0-9][A-Z0-9_\-]+\w*)\s+(.+)", line)
            if am and len(am.group(1)) >= 4:
                part = am.group(1)
                desc = am.group(2)[:120].strip()
                keywords = [
                    "GPM", "PSI", "NPT", "BSP", "MESH", "ORIFICE", "GROOVE",
                    "REDUCTION", "°", "PLUG", "COUPLER", "LANCE", "SCREEN",
                    "VALVE", "SPRAY", "NOZZLE", "FILTER", "GAUGE", "SWITCH",
                    "PULLEY", "OIL",
                ]
                if any(x in desc.upper() for x in keywords):
                    section = current_section or "General"
                    if section not in accessories:
                        accessories[section] = []
                    accessories[section].append([part, desc])
    return accessories


def extract_troubleshooting(pages):
    """Look for troubleshooting content in pages."""
    problems = {}
    current_problem = None
    for text in pages:
        lines = text.split("\n")
        for line in lines:
            # Detect problem headers (common patterns in troubleshooting PDFs)
            if re.match(r"^[A-Z ]{10,}$", line.strip()) and any(
                kw in line.upper()
                for kw in ["PRESSURE", "PULSATION", "LEAK", "NOISE", "OVERHEAT", "PACKING"]
            ):
                current_problem = line.strip().title()
                problems[current_problem] = []
            elif current_problem and ":" in line:
                parts = line.split(":", 1)
                if len(parts) == 2 and len(parts[0]) < 80:
                    problems[current_problem].append({
                        "cause": parts[0].strip(),
                        "remedy": parts[1].strip(),
                    })
    return problems


def main():
    print(f"═══ General Pump Knowledge Base Builder ═══")
    print(f"Scanning: {os.path.abspath(PDF_FOLDER)}\n")

    # Find all PDFs
    pdf_files = sorted(
        [f for f in os.listdir(PDF_FOLDER) if f.lower().endswith(".pdf")]
    )
    if not pdf_files:
        print(f"ERROR: No PDF files found in {PDF_FOLDER}")
        sys.exit(1)

    print(f"Found {len(pdf_files)} PDFs:")
    for f in pdf_files:
        size = os.path.getsize(os.path.join(PDF_FOLDER, f))
        print(f"  • {f} ({size / 1024:.0f} KB)")

    # Extract from all PDFs
    all_pump_models = []
    all_accessories = {}
    all_pages_text = {}

    for pdf_file in pdf_files:
        path = os.path.join(PDF_FOLDER, pdf_file)
        print(f"\nProcessing: {pdf_file}...")
        pages = extract_text(path)
        all_pages_text[pdf_file] = pages
        print(f"  Extracted {len(pages)} pages")

        # Extract pump models
        models = extract_pump_models(pages)
        if models:
            print(f"  Found {len(models)} pump models")
            all_pump_models.extend(models)

        # Extract accessories
        acc = extract_accessories(pages)
        for cat, items in acc.items():
            if cat not in all_accessories:
                all_accessories[cat] = []
            all_accessories[cat].extend(items)

    # Deduplicate models
    seen = set()
    unique_models = []
    for m in all_pump_models:
        if m[0] not in seen:
            seen.add(m[0])
            unique_models.append(m)

    print(f"\n═══ SUMMARY ═══")
    print(f"  Pump models: {len(unique_models)}")
    print(f"  Accessory categories: {len(all_accessories)}")
    print(f"  Total accessory items: {sum(len(v) for v in all_accessories.values())}")

    # Generate knowledge-base.js
    # NOTE: The static KB sections (troubleshooting, service procedures, maintenance,
    # system design, oil recommendations, warranty) are defined in the template below.
    # They were manually curated from the original PDFs for accuracy.
    # The pump models and accessories are auto-extracted above.

    js = generate_js(unique_models, all_accessories, pdf_files)

    output_path = os.path.join(PDF_FOLDER, OUTPUT_FILE)
    with open(output_path, "w") as f:
        f.write(js)

    size = os.path.getsize(output_path)
    print(f"\n✓ Generated {OUTPUT_FILE} ({size / 1024:.1f} KB)")
    print(f"  Location: {os.path.abspath(output_path)}")


def generate_js(pump_models, accessories, source_files):
    """Generate the knowledge-base.js file content."""
    today = datetime.date.today().isoformat()
    sources_js = json.dumps([f"{f}" for f in source_files])

    return f"""// ═══════════════════════════════════════════════════════════════
// GENERAL PUMP KNOWLEDGE BASE
// Auto-generated by build-kb.py on {today}
// Do not edit manually — run build-kb.py to rebuild.
// ═══════════════════════════════════════════════════════════════

const KB = {{}};

// ─── PUMP CATALOG: {len(pump_models)} models ───
// Format: [model, gpm, psi, rpm, hp, weight, series]
KB.pumpModels = {json.dumps(pump_models)};

// ─── ACCESSORIES ───
KB.accessories = {json.dumps(accessories)};

// ─── OIL RECOMMENDATIONS ───
KB.oilRecommendations = {{
  series8090: {{
    label: "GP Series 8090", weight: "80/90 Weight Gear Lube", badge: "s8090",
    pumps: ["T41","T61","T81","T121","T151","T1551","T1591","T3551","T4251","T9971","T9971GR","TS1041","TS1531","CW1012","CW1541","CW61","CW81","YGR0750","YGR1000","YGR1000P","YGR1125","YGR1125P","ZGRS1000","ZGRS1125","ZGRS1000J","ZGRPTO"]
  }},
  series220: {{
    label: "GP Series 220", weight: "50 Weight", badge: "s220",
    pumps: ["HF","HFN","HTCK3623S","HTCK4050S","KE","KE36M","KEZ","KF","KF40M","KFMB","KFMZ","KFZ","KS","LK36","LK40","LK45","LK50","LK55","LK60","LKN36","LKN40","LKN45","LKN50","LKN55","LKN60","MK40","MK45","MK50","MK55","MK60","MK65","MKS40","MKS45","MKS50","MKS55","MKS60","MKS65","MW32","MW36","MW40","MW45","MW50","MW55","MW55M","MWN32","MWN36","MWN40","MWN45","MWN50","MWN55","SK","VF","VK","VS"]
  }},
  series100: {{
    label: "GP Series 100", weight: "30 Weight, Non-Detergent", badge: "s100",
    pumps: ["100648","100656","AT0033","AT0055","AT0088","AT0088B","AT0111","AT0177","AT0177B","CW2004","CW2040","CW24","CW3040","EZ2530SUI","EZ2536E","EZ2536EUI","EZ2536S","EZ2542E","EZ2542S","EZ2545E","EZ2545GUI","EZ2545S","EZ2555E","EZ2555S","EZ2642N","EZ3030G34","EZ3030G34UI","EZ3035G","EZ3035GUI","EZ3035GUK","EZ3036N","EZ3040G","EZ3040GUI","EZ3040GUK","EZ3040S","EZ3042S","EZ3045G","EZ4030G34","EZ4035E34","EZ4035G34","EZ4040E34","EZ4040G","HTC1505E345","HTC1506S17","HTC1509E175","HTC1509S17","HTC1511S17","HTF2018S","HTF2221S","HTF2421S","HTS2016S","HTS2210S","HTS2215S","HTS2219S","HTW3624S","HTXS1810S","HTXS1812S","HTXS1813S","T1011","T1321","T1621","T2031","T721B","T731B","T9051EBF","T9051EBFU","T9051EBFUI","T921","T9211","T9281","T9711EBF","T9721B","T9721EBF","T9731B","T9731EBF","T991","T991GR","T9951","TC1502E175","TC1504E345","TC1505E345","TC1506E345","TC1506E346","TC1506G","TC1506GUI","TC1507E345","TC1507E346","TC1507G","TC1507GUI","TC1507S34","TC1508E175","TC1508E346","TC1508G","TC1508GUI","TC1508S34","TC1509E175","TC1509E17N","TC1509G","TC1509GUI","TC1509S17","TC1511S17","TC1802E175","TC1809E175","TC1809E17N","TC1809S17","TC1811S17","TP2520J34","TP2520J34UIL","TP2526J34","TP2526J34UIL","TP2530J34","TP2530J34UIL","TP2533J34","TP2533J34UIL","TS1011","TS1021","TS1321","TS1331","TS1511","TS1621","TS1711","TS1811","TS2011","TS2012SS","TS2013","TS2016SS","TS2021","TS2212SS","TS2291","TS921","TSF1819","TSF2019","TSF2019DS","TSF2019SS","TSF2021","TSF2021SS","TSF2219","TSF2221","TSF2221SS","TSF2421","TSF2421SS","TSF2819","TT2028GBF","TT2035EBF","TT2035EBFUI","TT2035GBF","TT901","TT9061EBF","TT9061EBFU","TT9061EBFUI","TT9061GBF","TT9071EBF","TT9071EBFU","TT9071EBFUI","TT9071GBF","TT9111","TT9111EBF","TT931","TT9351","TT941","TT9441","TT951","TX1505G6","TX1506G6","TX1506G8","TX1506G8UK","TX1506S34","TX1508G6","TX1508G8","TX1508G8UIA","TX1508G8UK","TX1508S34","TX1509G8UIA","TX1509G8UK","TX1510E349","TX1510G8UIA","TX1510G8UK","TX1510S17SS","TX1510S34","TX1512E179","TX1512S17","TX1512S17SS","TX1810E179","EP1306S34","EP1308S34","EP1505G6","EP1506G6","EP1506G8","EP1508G6","EP1508G8","EP1509G8","EP1510G8","EP1306E34","EP1308E34","EP1310E34","EP1505E34","EP1506E34","EP1507E34","EP1508E34","EP1510E34","EP1505S34","EP1506S34","EP1507S34","EP1508S34","EP1510S34","ES1507S34","ES1509S34","ES1811S17","ES1813S17","ES2014S17","ET1305S34","ET1306S34","ET1307S34","ET1308S34","ET1309S34","ET1310S34","ET1311S34","ET1312S34","ET1504E34","ET1505E34","ET1505S34","ET1506S34","ET1507S34","ET1508S34","ET1509E17","ET1509S17","ET1807E17","ET1807S17","ET1809E17","ET1809S17","ET1810S17","ET1811S17","ET1511S17","ET1512S17"]
  }}
}};

// ─── TROUBLESHOOTING ───
KB.troubleshooting = {{
  pressure: {{icon:"📉",title:"Low Pressure",desc:"Causes and remedies for loss of system pressure",causes:[{{cause:"Belt slippage",remedy:"Tighten or replace belt; use correct belt type."}},{{cause:"Air leak in inlet plumbing",remedy:"Disassemble, reseal and reassemble all inlet connections."}},{{cause:"Relief valve stuck, partially plugged or improperly adjusted",remedy:"Clean, adjust relief valve; check for worn and dirty valve seats."}},{{cause:"Inlet suction strainer clogged or improperly sized",remedy:"Clean strainer. Use adequate size. Check more frequently."}},{{cause:"Worn packing — abrasives in fluid or severe cavitation",remedy:"Install proper filter. Suction at inlet manifold must be limited to lifting less than 20 ft of water or -8.5 PSI vacuum."}},{{cause:"Fouled or dirty inlet / discharge valves",remedy:"Clean inlet and discharge valve assemblies."}},{{cause:"Worn inlet or discharge valve; blocked or dirty",remedy:"Replace worn valves, valve seats and/or discharge hose."}},{{cause:"Leaky discharge hose",remedy:"Replace discharge hose."}},{{cause:"Restricted inlet or air entering inlet plumbing",remedy:"Use proper size inlet plumbing; check for airtight seal."}},{{cause:"Worn nozzle (nozzle has become too large)",remedy:"Replace nozzle with proper size."}},{{cause:"Insufficient RPM",remedy:"Increase RPM to rated speed per pump specifications."}},{{cause:"Incorrect operation of pressure adjustment valve",remedy:"Service or replace pressure adjustment valve."}}]}},
  pulsation: {{icon:"〰️",title:"Pulsation",desc:"Irregular pulsing or surging during operation",causes:[{{cause:"Valve stuck open",remedy:"Check all valves, remove foreign matter."}},{{cause:"Faulty pulsation damper",remedy:"Check pre-charge; if low, recharge or install a new one."}},{{cause:"Worn nozzle",remedy:"Replace nozzle, use proper size."}},{{cause:"Air leak in inlet plumbing",remedy:"Disassemble, reseal and reassemble all connections."}},{{cause:"Insufficient feeding",remedy:"Check suction line for obstructions, ensure water supply is adequate."}},{{cause:"Worn valves or pressure packings",remedy:"Replace worn valves and/or packings."}}]}},
  rough: {{icon:"🔴",title:"Rough Running / Very Low Pressure",desc:"Pump runs extremely rough with very low output",causes:[{{cause:"Inlet restrictions and/or air leaks",remedy:"Replace worn cup or cups, clean out foreign material, replace worn valves."}},{{cause:"Stuck inlet or discharge valve",remedy:"Clean valves and remove foreign material; replace worn valves."}},{{cause:"Insufficient feeding / pump not primed",remedy:"Check suction line for obstructions, ensure water supply is adequate."}},{{cause:"Worn valves or pressure packings",remedy:"Replace worn valves and/or packings."}},{{cause:"Bends, elbows, fittings along suction line obstructing flow",remedy:"Redesign suction line to minimize restrictions."}},{{cause:"Inlet filter dirty or too small",remedy:"Clean filter. Use adequate size."}},{{cause:"Cavitation",remedy:"Correct suction hose sizing, ensure adequate flow rate, check water temperature."}}]}},
  leak: {{icon:"💧",title:"Leaks (Water & Oil)",desc:"All types of water and oil leaks on the pump",items:[{{subtitle:"Water Leaking from Under Manifold",causes:[{{cause:"Worn packing",remedy:"Install new packing."}},{{cause:"Cracked plunger",remedy:"Replace plunger(s)."}}]}},{{subtitle:"Oil Leak Between Crankcase & Pumping Section",causes:[{{cause:"Worn crankcase piston rod seals or O-rings on plunger retainer",remedy:"Replace seals and O-rings."}}]}},{{subtitle:"Oil Leaking at Crankshaft Area",causes:[{{cause:"Worn crankshaft seal or improperly installed oil seal O-ring",remedy:"Remove oil seal retainer and replace damaged O-ring and/or seals."}}]}},{{subtitle:"Oil Leaking from Underside of Crankcase",causes:[{{cause:"Worn crankcase piston rod seals",remedy:"Replace seals."}},{{cause:"Scored piston rod",remedy:"Replace piston rod."}}]}},{{subtitle:"Water in Crankcase (milky oil)",causes:[{{cause:"Humid air condensing inside crankcase",remedy:"Change oil at regular intervals."}},{{cause:"Worn packing and/or piston rod sleeve",remedy:"Replace packing. Replace O-rings."}},{{cause:"Cracked plunger",remedy:"Replace plunger(s)."}}]}}]}},
  noise: {{icon:"🔊",title:"Loud Knocking / Noise",desc:"Unusual sounds from the pump",causes:[{{cause:"Pulley loose on crankshaft",remedy:"Check key and tighten set screw."}},{{cause:"Broken or worn bearing or connecting rod(s)",remedy:"Replace bearing or rod(s)."}},{{cause:"Valve stuck open or shut",remedy:"Replace bad valve."}},{{cause:"Scored or worn plunger",remedy:"Replace plungers."}},{{cause:"Air suction in inlet line",remedy:"Check all inlet connections for airtight seal."}},{{cause:"Irregular drive transmission motion",remedy:"Check belts, pulleys, and drive alignment."}}]}},
  packing: {{icon:"⚙️",title:"Frequent Packing Failure",desc:"Causes for short packing life",causes:[{{cause:"Overpressure to inlet manifold",remedy:"Reduce inlet pressure."}},{{cause:"Abrasive material in the fluid",remedy:"Install proper filtration."}},{{cause:"Excessive pressure and/or temperature",remedy:"Check pressures and fluid temperature; ensure within specified range."}},{{cause:"Running pump dry",remedy:"Do not run pump without water."}},{{cause:"Upstream chemical injection",remedy:"Use downstream injection instead."}},{{cause:"Scored or worn plunger",remedy:"Replace plungers."}}]}},
  overheating: {{icon:"🌡️",title:"Pump Overheating",desc:"Pump running hot or above normal temperature",causes:[{{cause:"Pump is overloaded",remedy:"Reduce pressure and/or RPM to within rated specifications."}},{{cause:"Oil level too low or wrong type",remedy:"Check oil level and refill with correct oil type."}},{{cause:"Incorrect alignment of pulleys",remedy:"Realign pulleys and transmission components."}},{{cause:"Pump not level",remedy:"Ensure pump is installed level on a flat, rigid surface."}},{{cause:"Excessive play in crankshaft bearings",remedy:"Replace bearings."}}]}}
}};

// ─── SERVICE PROCEDURES ───
KB.serviceProcedures = {{
  valves: {{icon:"🔧",title:"Servicing Valve Assemblies",desc:"Step-by-step valve inspection and replacement",steps:["All inlet and discharge valves can be serviced without disrupting the inlet or discharge plumbing.","Remove the valve cap and extract the valve assembly.","Examine O-rings and replace if there is any evidence of cuts, abrasions, or distortion.","Remove valve assembly (retainer, spring, valve, valve seat) from valve cavity.","Remove O-ring from valve cavity.","Only one valve kit is necessary to repair all the valves in the pump.","Inspect manifold for wear or damage.","Install new O-ring in valve cavity.","Insert assembly into valve cavity.","Replace valve cap and torque to specifications."]}},
  plungers: {{icon:"🔩",title:"Replacing Plungers",desc:"Step-by-step plunger removal and replacement",steps:["Remove the stainless steel piston screw and plunger from piston rod.","If the slinger washer comes off with the plunger, replace it before installing the new plunger.","Separate piston screw from plunger.","Install new O-ring and Teflon backup ring on piston screw.","Apply removable anaerobic thread sealant to threads of piston screw and press into plunger.","Slide new plunger over the piston guide and torque to specifications."],notes:"Examine plunger surfaces — they should be smooth and free from scoring, pitting, or cracks."}},
  vpackings: {{icon:"🛞",title:"Replacing V-Packings",desc:"Step-by-step V-packing seal replacement",steps:["Remove manifold from crankcase.","Insert extractor collet through main seal retainer. Extract retainers, V-packings and head rings.","Install front head ring, V-packing and long-life ring. Press firmly into cylinder.","Insert intermediate seal retainer, pressing firmly into cylinder.","Install rear head ring, V-packing and main seal retainer. Be careful not to cut O-ring.","Repeat this sequence for each cylinder.","Coat each plunger with grease and carefully remount manifold. Torque to specifications."],notes:"Packing assembly order: Head Ring → V-Packing → Long Life Ring → Intermediate Seal Retainer → Head Ring → V-Packing → Main Seal Retainer."}}
}};

// ─── MAINTENANCE ───
KB.maintenance = {{
  oilChange: "Change crankcase oil after an initial 50-hour break-in period. Change oil every 3 months or at 500-hour intervals thereafter.",
  every500: ["Check oil level","Check / Replace valves","Check / Replace valve seats","Check / Replace valve springs","Check / Replace valve guides","Check / Replace H.P. packings","Check / Replace L.P. packings"],
  every1000: ["Change oil","Full valve inspection and replacement","Complete packing inspection"],
  flushing: "A flushing operation with clean water is recommended after every daily operation.",
  freezing: "In areas where there is risk of freezing, protect the pump circuit. NEVER start until completely thawed.",
  startup: ["Ensure the suction line is perfectly airtight.","All On/Off valves are completely open.","The delivery line must discharge freely for priming.","All connections and fittings must be correctly tightened.","Verify oil level using the dipstick.","Check for correct direction of rotation on first start.","Start pump off-load for at least 3 minutes before pressurizing.","Before stopping, release pressure via the adjustment valve."]
}};

// ─── SYSTEM DESIGN ───
KB.systemDesign = {{
  pressure: {{title:"Pressure",text:"Pressure is the result of forcing a known volume (flow) through a known size orifice (spray tip). Measured in PSI."}},
  flow: {{title:"Flow",text:"Flow is determined by the pump shaft RPM. The faster the shaft rotates, the higher the output. Measured in GPM."}},
  motor: {{title:"Motor / Engine Sizing",text:"Size based on pump GPM and PSI. For gas engines, multiply electric HP by 1.5 to 1.8."}},
  unloader: {{title:"Unloader / Regulator Valve",text:"REQUIRED to redirect flow when the spray gun is closed. Mount as close to the pump outlet as possible."}},
  inletFilter: {{title:"Inlet Filter",text:"60–120 mesh screen filter necessary to stop foreign matter from entering the system."}},
  thermal: {{title:"Thermal Relief Valve",text:"Opens and dumps water at a predetermined temperature to prevent heat damage."}},
  hose: {{title:"High Pressure Hose",text:"Must be rated at least 50% greater than operating pressure. Use permanent couplings."}},
  pulley: {{title:"Pulley Formula",text:"Pump Pulley = (Motor RPM ÷ Desired Pump RPM) × Motor Pulley Diameter."}},
  sprayTip: {{title:"Spray Tip Selection",text:"Must know output GPM and desired PSI. A tip too small causes overpressurization."}},
  plumbing: {{title:"Plumbing Best Practices",text:"Avoid bends and restrictions — they cause cavitation and premature wear."}}
}};

// ─── WARRANTY ───
KB.warranty = {{
  pumpWarranty: "GP Companies, Inc. warrants each pump to be free of defects in material or workmanship for five (5) years from date of shipment.",
  manifoldWarranty: "All forged brass pump manifolds are warranted for the life of the pump.",
  consumerWarranty: "Consumer Pumps carry a two (2) year warranty.",
  accessoryWarranty: "All accessories are warranted for one (1) year from date of shipment.",
  notCovered: ["Normal wear and tear","Misuse, abuse, neglect, or unauthorized modifications","Incompatible fluids","Operation exceeding rated pressures and temperatures","Failure to follow maintenance requirements"],
  wearParts: ["Packing (high and low pressure)","Plungers","Valves and valve seats","O-rings","Oil seals"]
}};

// ─── SERIES SPECIFICATIONS ───
KB.seriesSpecs = {{}};

// ─── METADATA ───
KB.meta = {{
  version: "2.0",
  generated: "{today}",
  sources: {sources_js},
  stats: {{ pumps: {len(pump_models)}, accessories: {sum(len(v) for v in accessories.values())}, troubleshootingProblems: 7, serviceProcedures: 3 }}
}};
"""


if __name__ == "__main__":
    main()
