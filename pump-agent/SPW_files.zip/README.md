# General Pump Troubleshooter — v2.0

## Files

| File | Purpose |
|------|---------|
| `index.html` | The app — open in any browser |
| `knowledge-base.js` | All data (pump models, accessories, troubleshooting, etc.) |
| `build-kb.py` | Python script to rebuild knowledge-base.js from PDFs |

## How to Use

1. Put `index.html` and `knowledge-base.js` in the same folder
2. Open `index.html` in a browser — works offline, no server needed

## Adding New PDFs

When you get new manuals or data sheets:

1. Put all your PDFs in one folder
2. Run: `python3 build-kb.py /path/to/pdf/folder`
3. Copy the new `knowledge-base.js` next to `index.html`
4. Refresh the browser

### Requirements for build-kb.py

```
pip install pdfplumber
```

For scanned/image PDFs (OCR):
```
sudo apt install tesseract-ocr
pip install pytesseract Pillow
```

## Architecture

The app is split into two files so you can update data without touching the UI:

- **index.html** — All UI, styling, and search logic. Rarely needs changes.
- **knowledge-base.js** — Pure data. Rebuild anytime with build-kb.py.

The JS file defines a global `KB` object with sections for pump models, accessories,
oil recommendations, troubleshooting, service procedures, maintenance, system design,
and warranty info.

## Current Data Sources (9 PDFs)

- 2018-Catalog-Online.pdf (117 pages) — 372 pump models, 851 accessories
- Troubleshooting.pdf — 15 problem categories
- ServiceManual.pdf — Installation, operation, service procedures
- 47_Series_Service_Instructions.pdf — Valve, manifold, plunger procedures
- KFMZOwnerManual.pdf — Safety, installation, maintenance
- OilRecommend.pdf — Oil specs for all pump models
- General_Pump_TS2021_Data_Sheet_2022.pdf — Technical specifications
- MKRepairMan.pdf — Detailed repair instructions
